<?php /* Smarty version 3.1.27, created on 2015-12-02 00:22:02
         compiled from "C:\xampp\htdocs\PHP avanzado\styles\templates\overall\header.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:29825565e2b9a461858_60707673%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '56415a19e8691d57037d27828f75edf872faa084' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP avanzado\\styles\\templates\\overall\\header.tpl',
      1 => 1449012099,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29825565e2b9a461858_60707673',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_565e2b9b713fb2_40383531',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_565e2b9b713fb2_40383531')) {
function content_565e2b9b713fb2_40383531 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '29825565e2b9a461858_60707673';
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>Prinick Tutoriales - www.prinick.com</title>

    <!-- Bootstrap core CSS -->
    <link href="styles/css/bootstrap.min.css" rel="stylesheet">
    <link href="styles/css/style.min.css" rel="stylesheet">
    <link href="fonts/font-awesome.min.css" rel="stylesheet">
    <link href="styles/css/home.css" rel="stylesheet">
    <link href="styles/css/posts.css" rel="stylesheet">
    <link href="styles/css/datepicker.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <?php echo '<script'; ?>
 src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"><?php echo '</script'; ?>
>
    <![endif]-->
</head>
<?php }
}
?>