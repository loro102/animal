<?php /* Smarty version 3.1.27, created on 2015-12-02 01:10:20
         compiled from "C:\xampp\htdocs\PHP avanzado\styles\templates\overall\menu.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:8626565e36ec664813_23780059%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cf7d8afd762c59e8ab2103962c9859f320b33161' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP avanzado\\styles\\templates\\overall\\menu.tpl',
      1 => 1449015017,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8626565e36ec664813_23780059',
  'variables' => 
  array (
    'user' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_565e36ec9d5b36_24664518',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_565e36ec9d5b36_24664518')) {
function content_565e36ec9d5b36_24664518 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '8626565e36ec664813_23780059';
?>
<ul class="nav nav-sidebar">

    <?php if (isset($_GET['view']) && $_GET['view'] == 'post') {?>
    <li class="active"><a href="#">Vsualizacion de post</a></li>
    <?php }?>
    <?php if (isset($_GET['view']) && $_GET['view'] == 'perfil') {?>
    <li class="active"><a href="#">Perfil de <?php echo $_smarty_tpl->tpl_vars['user']->value['user'];?>
</a></li>
    <?php }?>
    <?php if (isset($_GET['view']) && $_GET['view'] == 'cuenta') {?>
    <li class="active"><a href="#">Tu cuenta</a></li>
    <?php }?>
    <?php if (isset($_GET['view']) && $_GET['view'] == 'buscar') {?>
    <li class="active"><a href="#">Resultado de Búsqueda</a></li>
    <?php }?>


    


    <?php if (isset($_GET['type']) && $_GET['type'] == 'tops') {?>
    <li class="active"><?php } else { ?><li><?php }?>
    <a href="?view=index&type=tops">Los mejores</a></li>
    <?php if ((!isset($_GET['type']) && isset($_GET['view']) && $_GET['view'] == 'index') || (!isset($_GET['view']))) {?>
    <li class="active"><?php } else { ?><li><?php }?>
    <a href="?view=index">Inicio</a></li>
    <?php if (isset($_GET['type']) && $_GET['type'] == '1') {?>
    <li class="active"><?php } else { ?><li><?php }?><a href="?view=index&type=1">Categoria 1</a></li>
    <?php if (isset($_GET['type']) && $_GET['type'] == '2') {?>
    <li class="active"><?php } else { ?><li><?php }?><a href="?view=index&type=2">Categoria 2</a></li>
    <?php if (isset($_GET['type']) && $_GET['type'] == '3') {?>
    <li class="active"><?php } else { ?><li><?php }?><a href="?view=index&type=3">Categoria 3</a></li>

</ul><?php }
}
?>