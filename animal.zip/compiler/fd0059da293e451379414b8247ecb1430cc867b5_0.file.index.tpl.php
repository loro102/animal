<?php /* Smarty version 3.1.27, created on 2015-12-01 13:05:36
         compiled from "C:\xampp\htdocs\PHP avanzado\styles\templates\home\index.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:6497565d8d10a21fe6_70161735%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fd0059da293e451379414b8247ecb1430cc867b5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP avanzado\\styles\\templates\\home\\index.tpl',
      1 => 1448971534,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6497565d8d10a21fe6_70161735',
  'variables' => 
  array (
    'titulo' => 0,
    'posts' => 0,
    'pt' => 0,
    'pags' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_565d8d10e11138_73053192',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_565d8d10e11138_73053192')) {
function content_565d8d10e11138_73053192 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '6497565d8d10a21fe6_70161735';
echo $_smarty_tpl->getSubTemplate ('overall/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<body>

    <?php echo $_smarty_tpl->getSubTemplate ('overall/nav.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-md-2 sidebar">
                <?php echo $_smarty_tpl->getSubTemplate ('overall/menu.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                <h2 class="sub-header"><?php echo $_smarty_tpl->tpl_vars['titulo']->value;?>
</h2>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th style="width: 65%;">Post</th>
                            <th style="width: 25%;">Autor</th>
                            <th style="width: 5%;">Puntos</th>
                            <th style="width: 5%;">Comentarios</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (isset($_smarty_tpl->tpl_vars['posts']->value)) {?>
                        <?php
$_from = $_smarty_tpl->tpl_vars['posts']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['pt'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['pt']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['pt']->value) {
$_smarty_tpl->tpl_vars['pt']->_loop = true;
$foreach_pt_Sav = $_smarty_tpl->tpl_vars['pt'];
?>
                        <tr>
                            <td><a href="?view=post&id=<?php echo $_smarty_tpl->tpl_vars['pt']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['pt']->value['titulo'];?>
</a></td>
                            <td><a href="?view=perfil&id=<?php echo $_smarty_tpl->tpl_vars['pt']->value['id_dueno'];?>
"><?php echo $_smarty_tpl->tpl_vars['pt']->value['dueno'];?>
</a></td>
                            <td style="text-align: center;"><?php echo $_smarty_tpl->tpl_vars['pt']->value['puntos'];?>
</td>
                            <td style="text-align: center;">0</td>
                        </tr>
                        <?php
$_smarty_tpl->tpl_vars['pt'] = $foreach_pt_Sav;
}
?>
                        <?php } else { ?>
                        <tr>
                            <td colspan="4">No Existen posts</td>
                        </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>
                <?php if (isset($_smarty_tpl->tpl_vars['posts']->value)) {?>
                <div class="btn-group btn-group-justified" role="group" aria-label="..." >
                    <?php if (!isset($_GET['pag'])) {?>
                        <a type="button" class="btn btn-default disabled" href="#">Anterior</a>
                        <?php if ($_smarty_tpl->tpl_vars['pags']->value > 1) {?>
                            <?php if (isset($_GET['type'])) {?>
                            <a type="button" class="btn btn-default" href="?view=index&type=<?php echo $_GET['type'];?>
&pag=2">Siguiente</a>
                            <?php } elseif (isset($_GET['view']) && $_GET['view'] == 'buscar') {?>
                            <a type="button" class="btn btn-default" href="?view=buscar&pag=2">Siguiente</a>
                            <?php } else { ?>
                            <a type="button" class="btn btn-default" href="?view=index&pag=2">Siguiente</a>
                            <?php }?>
                        <?php } else { ?>
                        <a type="button" class="btn btn-default disabled" href="#">Siguiente</a>
                        <?php }?>
                    <?php } else { ?>
                        <?php if ($_GET['pag'] <= 1) {?>
                        <a type="button" class="btn btn-default disabled" href="#">Anterior</a>
                        <?php } else { ?>
                            <?php if (isset($_GET['type'])) {?>
                            <a type="button" class="btn btn-default" href="?view=index&type=<?php echo $_GET['type'];?>
&pag=<?php echo $_GET['pag']-1;?>
">Anterior</a>
                                <?php } elseif (isset($_GET['view']) && $_GET['view'] == 'buscar') {?>
                            <a type="button" class="btn btn-default" href="?view=buscar&pag=<?php echo $_GET['pag']-1;?>
">Anterior</a>
                            <?php } else { ?>
                            <a type="button" class="btn btn-default" href="?view=index&pag=<?php echo $_GET['pag']-1;?>
">Anterior</a>
                            <?php }?>
                        <?php }?>
                        <?php if ($_smarty_tpl->tpl_vars['pags']->value > 1 && $_GET['pag'] >= 1 && $_GET['pag'] < $_smarty_tpl->tpl_vars['pags']->value) {?>
                            <?php if (isset($_GET['type'])) {?>
                            <a type="button" class="btn btn-default" href="?view=index&type=<?php echo $_GET['type'];?>
&pag=<?php echo $_GET['pag']+1;?>
">Siguiente</a>
                                <?php } elseif (isset($_GET['view']) && $_GET['view'] == 'buscar') {?>
                            <a type="button" class="btn btn-default" href="?view=buscar&pag=<?php echo $_GET['pag']+1;?>
">Siguiente</a>
                            <?php } else { ?>
                            <a type="button" class="btn btn-default" href="?view=index&pag=<?php echo $_GET['pag']+1;?>
">Siguiente</a>
                            <?php }?>
                        <?php } else { ?>
                        <a type="button" class="btn btn-default disabled" href="#">Siguiente</a>
                        <?php }?>
                    <?php }?>
                </div>
                <?php } else { ?>
                <?php }?>
            </div>
        </div>
    </div>

    <?php echo $_smarty_tpl->getSubTemplate ('overall/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

</body>
</html>       <?php }
}
?>