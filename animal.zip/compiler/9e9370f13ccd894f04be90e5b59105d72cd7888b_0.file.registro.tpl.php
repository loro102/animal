<?php /* Smarty version 3.1.27, created on 2015-11-29 12:16:15
         compiled from "C:\xampp\htdocs\PHP avanzado\styles\templates\public\registro.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:23752565ade7f47c390_71011855%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9e9370f13ccd894f04be90e5b59105d72cd7888b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP avanzado\\styles\\templates\\public\\registro.tpl',
      1 => 1448736377,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '23752565ade7f47c390_71011855',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_565ade7fc11e78_03131073',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_565ade7fc11e78_03131073')) {
function content_565ade7fc11e78_03131073 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '23752565ade7f47c390_71011855';
echo $_smarty_tpl->getSubTemplate ('overall/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<body>

    <?php echo $_smarty_tpl->getSubTemplate ('overall/nav.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

    <div class="container" style="margin-top: 30px;">
        <center>
            <div id="_AJAX_">

            </div>
            <div class="container">
                <div class="form-signin" style="width:500px;">
                    <h2 class="form-signin-heading">Registrate</h2>
                    <label for="user" class="sr-only">Usuario</label>
                    <input type="text" id="user" class="form-control" placeholder="Introduce tu usuario" required=""
                           autofocus="">
                    <label for="pass" class="sr-only">Contraseña</label>
                    <input type="password" id="pass" class="form-control" placeholder="Introduce tu contraseña"
                           required="">
                    <label for="email" class="sr-only">Email</label>
                    <input type="email" id="email" class="form-control" placeholder="Introduce tu correo electronico"
                           required=""><br>
                    <button class="btn btn-primary btn-block" id="send_request" type="button">Registrar</button>
                </div>
            </div>
        </center>
    </div>
    <?php echo $_smarty_tpl->getSubTemplate ('overall/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

    <?php echo '<script'; ?>
>
        window.onload = function () {
            document.getElementById('send_request').onclick = function () {
                var connect, user, pass, email, form, result;
                user = document.getElementById('user').value;
                pass = document.getElementById('pass').value;
                email = document.getElementById('email').value;
                if (user != '' && pass != '' && email != '') {
                    form = 'user=' + user + '&pass=' + pass + '&email=' + email;
                    connect = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');

                    connect.onreadystatechange = function () {
                        if (connect.readyState == 4 && connect.status == 200) {
                            if (parseInt(connect.responseText) == 1) {
                                result = '<div class="alert alert-dismissible alert-success" style="width:500px">';
                                result += '<button type="button" class="close" data-dismiss="alert">X</button>';
                                result += '<strong>Registro Completado</strong>';
                                result += '</div>';
                                location.href = '?view=index';
                                document.getElementById('_AJAX_').innerHTML = result;
                            } else if (parseInt(connect.responseText) == 2) {
                                //ERROR: Los datos son incorrectos
                                result = '<div class="alert alert-dismissible alert-danger" style="width:500px">';
                                result += '<button type="button" class="close" data-dismiss="alert">X</button>';
                                result += '<strong>ERROR:</strong> El usuario ya existe.';
                                result += '</div>';
                                document.getElementById('_AJAX_').innerHTML = result;
                            } else if (parseInt(connect.responseText) == 3) {
                                result = '<div class="alert alert-dismissible alert-danger" style="width:500px">';
                                result += '<button type="button" class="close" data-dismiss="alert">X</button>';
                                result += '<strong>ERROR:</strong> El email ya existe.';
                                result += '</div>';
                                document.getElementById('_AJAX_').innerHTML = result;
                            }else{
                                result = '<div class="alert alert-dismissible alert-danger" style="width:500px">';
                                result += '<button type="button" class="close" data-dismiss="alert">X</button>';
                                result += '<strong>ERROR:</strong> Credenciales incorrectas.';
                                result += '</div>';
                                document.getElementById('_AJAX_').innerHTML = result;
                            }
                        } else if (connect.readyState != 4) {
                            result = '<div class="alert alert-dismissible alert-warning" style="width:500px">';
                            result += '<button type="button" class="close" data-dismiss="alert">X</button>';
                            result += '<strong>REGISTRANDO . . .</strong>';
                            result += '</div>';
                            document.getElementById('_AJAX_').innerHTML = result;
                        }
                    };
                    connect.open('POST', '?view=reg', true);
                    connect.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    connect.send(form);
                } else {
                    //ERROR:Campos vacios
                    result = '<div class="alert alert-dismissible alert-danger" style="width:500px">';
                    result += '<button type="button" class="close" data-dismiss="alert">X</button>';
                    result += '<strong>ERROR:</strong> Todos los campos no pueden estar vacios.';
                    result += '</div>';
                    document.getElementById('_AJAX_').innerHTML = result;
                }
            }
        }
    <?php echo '</script'; ?>
>


</body>
</html><?php }
}
?>