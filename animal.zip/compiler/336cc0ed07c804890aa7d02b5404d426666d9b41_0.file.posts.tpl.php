<?php /* Smarty version 3.1.27, created on 2015-12-02 16:20:17
         compiled from "C:\xampp\htdocs\PHP avanzado\styles\templates\posts\posts.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:32240565f0c313fa866_45341757%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '336cc0ed07c804890aa7d02b5404d426666d9b41' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP avanzado\\styles\\templates\\posts\\posts.tpl',
      1 => 1449069608,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '32240565f0c313fa866_45341757',
  'variables' => 
  array (
    'post' => 0,
    'image' => 0,
    'user' => 0,
    'c_estado' => 0,
    'estado' => 0,
    'contenido' => 0,
    'x' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_565f0c31614658_97554297',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_565f0c31614658_97554297')) {
function content_565f0c31614658_97554297 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '32240565f0c313fa866_45341757';
echo $_smarty_tpl->getSubTemplate ('overall/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<body>

    <?php echo $_smarty_tpl->getSubTemplate ('overall/nav.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 col-md-2 sidebar">
                <?php echo $_smarty_tpl->getSubTemplate ('overall/menu.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                <?php if (isset($_smarty_tpl->tpl_vars['post']->value)) {?>
                <h2 class="sub-header"><?php echo $_smarty_tpl->tpl_vars['post']->value['titulo'];?>
</h2>

                <!-- Post Principal -->
                <div class="media">
                    <div class="media-left" style="text-align: center;">
                        <a href="?view=perfil&id=<?php echo $_smarty_tpl->tpl_vars['post']->value['dueno'];?>
" target="_blank">
                            <img class="media-object" src="<?php echo $_smarty_tpl->tpl_vars['image']->value;?>
" width="80" height="80" />
                        </a>
                        <small><strong><?php echo $_smarty_tpl->tpl_vars['user']->value;?>
</strong> <br /> <span style="color: <?php echo $_smarty_tpl->tpl_vars['c_estado']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['estado']->value;?>
</span></small>
                    </div>
                    <div class="media-body principal-post">
                        <?php echo $_smarty_tpl->tpl_vars['contenido']->value;?>

                    </div>
                </div>
                <!-- Post Principal -->

                <!-- Comentario -->
                <div class="media">
                    <div class="media-body comun-post">
                        Esto es un comentario
                    </div>
                    <div class="media-right" style="text-align: center;">
                        <a href="?view=perfil&user=ID">
                            <img class="media-object" src="uploads/avatar/default.png" width="80" height="80" />
                        </a>
                        <small><strong>Usuario</strong> <br /> <span style="color: #FF0000">Offline</span></small>
                    </div>
                </div>
                <!-- Comentario -->

                <!-- AJAX de comentarios -->
                <div id="_COMMENTS_">
                    <!--<div class="alert alert-warning" style="margin: 15px 0px -10px 0px;background:#d6b62d;" role="alert">Haciendo espacio para tu comentario...</div>-->
                </div>

                <?php if (isset($_SESSION['user'])) {?>
                <div id="_POINTS_">
                    <nav>
                        <center>
                            <ul class="pagination">
                                <?php $_smarty_tpl->tpl_vars['x'] = new Smarty_Variable;$_smarty_tpl->tpl_vars['x']->step = 1;$_smarty_tpl->tpl_vars['x']->total = (int) ceil(($_smarty_tpl->tpl_vars['x']->step > 0 ? 10+1 - (1) : 1-(10)+1)/abs($_smarty_tpl->tpl_vars['x']->step));
if ($_smarty_tpl->tpl_vars['x']->total > 0) {
for ($_smarty_tpl->tpl_vars['x']->value = 1, $_smarty_tpl->tpl_vars['x']->iteration = 1;$_smarty_tpl->tpl_vars['x']->iteration <= $_smarty_tpl->tpl_vars['x']->total;$_smarty_tpl->tpl_vars['x']->value += $_smarty_tpl->tpl_vars['x']->step, $_smarty_tpl->tpl_vars['x']->iteration++) {
$_smarty_tpl->tpl_vars['x']->first = $_smarty_tpl->tpl_vars['x']->iteration == 1;$_smarty_tpl->tpl_vars['x']->last = $_smarty_tpl->tpl_vars['x']->iteration == $_smarty_tpl->tpl_vars['x']->total;?>
                                <li><a style="cursor:pointer;" onclick="AddPoints(<?php echo $_smarty_tpl->tpl_vars['x']->value;?>
);"><?php echo $_smarty_tpl->tpl_vars['x']->value;?>
</a></li>
                                <?php }} ?>
                            </ul>
                        </center>
                    </nav>

                    <!--<nav>
                        <center>
                              <div class="puntos-agregados">Puntos agregados correctamente</div>
                        </center>
                    </nav>
                    <nav>
                        <center>
                              <div class="puntos-no-agregados">Ya has puntuado antes este post</div>
                        </center>
                    </nav>-->
                </div>
                <?php }?>
                <!-- condición de inciio de sesión -->
                <?php if (isset($_SESSION['user'])) {?>
                <div class="media">
                    <div class="media-body">
                        <textarea class="form-control" id="comentario" placeholder="Hacer un comentario..."></textarea>
                        <center>
                            <a style="margin-top: 7px;" href="#" id="send_request" class="btn btn-primary btn-sm">Comentar</a>
                        </center>
                    </div>
                    <div class="media-right" style="text-align: center;">
                        <img class="media-object" src="uploads/avatar/default.png" width="80" height="80" />
                    </div>
                </div>
                <?php } else { ?>
                <div class="media">
                    <div class="alert alert-warning" role="alert" style="text-align:center;">
                        <strong>Debes <a href="?view=login">iniciar sesion</a> para poder comentar.</strong>
                    </div>
                </div>
                <?php }?>
                <?php } else { ?>
                <div class="media">
                    <div class="alert alert-danger" role="alert">
                        <strong>ERROR:</strong> El post solicitado no existe o ha sido borrado.
                    </div>
                </div>
                <?php }?>
            </div>
        </div>
    </div>

    <?php echo $_smarty_tpl->getSubTemplate ('overall/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

    <?php if (isset($_SESSION['user'])) {?>
    <?php echo '<script'; ?>
>
        function AddPoints($points) {
            var connect, session, form, result;
            if (parseInt($points) >= 1 && parseInt($points) <= 10 && <?php echo $_SESSION['id'];?>
 != <?php echo $_smarty_tpl->tpl_vars['post']->value['dueno'];?>
 ) {
                form = 'points=' + $points;
                connect = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');

                connect.onreadystatechange = function () {
                    if (connect.readyState == 4 && connect.status == 200) {
                        if (parseInt(connect.responseText) == 1) {
                            //Conectado con exito
                            //Se redirecciona
                            result = '<nav><center>';
                            result += '<div class="puntos-agregados">Puntos agregados correctamente</div>';
                            result += '</center></nav>';
                            document.getElementById('_POINTS_').innerHTML = result;
                        } else {
                            //ERROR: Los puntos ya han sido agregados
                            result = '<nav><center>';
                            result += '<div class="puntos-no-agregados">Ya has puntuado antes este post</div>';
                            result += '</center></nav>';
                            document.getElementById('_POINTS_').innerHTML = result;
                        }
                    } else if (connect.readyState != 4) {
                        //procesando
                        result = '<nav><center>';
                        result += '<div class="agregando-puntos">agregando puntos</div>';
                        result += '</center></nav>';

                    }
                };
                connect.open('POST', '?view=post&id=<?php echo $_GET['id'];?>
&mode=puntos', true);
                connect.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                connect.send(form);
            }else {
                //ERROR: Los puntos ya han sido agregados
                result = '<nav><center>';
                result += '<div class="puntos-no-agregados">No puedes puntuarte tu mismo</div>';
                result += '</center></nav>';
                document.getElementById('_POINTS_').innerHTML = result;
            }
        }
    <?php echo '</script'; ?>
>

    <?php }?>
</body>
</html>       <?php }
}
?>