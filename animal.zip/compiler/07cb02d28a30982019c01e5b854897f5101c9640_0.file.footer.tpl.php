<?php /* Smarty version 3.1.27, created on 2015-11-29 20:29:48
         compiled from "C:\xampp\htdocs\PHP avanzado\styles\templates\overall\footer.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:20500565b522cd7c4d0_63781923%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '07cb02d28a30982019c01e5b854897f5101c9640' => 
    array (
      0 => 'C:\\xampp\\htdocs\\PHP avanzado\\styles\\templates\\overall\\footer.tpl',
      1 => 1448824945,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20500565b522cd7c4d0_63781923',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_565b522cd83ee8_21968541',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_565b522cd83ee8_21968541')) {
function content_565b522cd83ee8_21968541 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '20500565b522cd7c4d0_63781923';
?>
<?php echo '<script'; ?>
 src="http://code.jquery.com/jquery-1.11.3.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="styles/js/bootstrap.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="styles/js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
<?php }
}
?>