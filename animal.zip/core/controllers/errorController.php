<?php
/**
 * Created by PhpStorm.
 * User: loro102
 * Date: 27/11/2015
 * Time: 13:30
 */
echo'error';